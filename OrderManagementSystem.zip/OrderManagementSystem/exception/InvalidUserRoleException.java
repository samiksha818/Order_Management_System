package exception;

public class InvalidUserRoleException extends Exception {
    public InvalidUserRoleException(String message) {
        super(message);
    }
}

